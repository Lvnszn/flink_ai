#
# Copyright 2018 Analytics Zoo Authors.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#

from zoo.serving.client import InputQueue, OutputQueue
import os
import cv2
import json
import time
from optparse import OptionParser


def run(path):
    input_api = InputQueue("localhost", "6379")
    base_path = path

    if not base_path:
        raise EOFError("You have to set your image path")
    output_api = OutputQueue()
    output_api.dequeue()

    import numpy as np
    a = np.array([0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0])
    b = np.array([5305,26])
    c = np.array([18])
    d = np.array([[1,2],[3,4]])
    e = np.array([1,2])
    z = np.zeros((1, 128))
    shape = np.array([124])
    i = np.array([[4, 2, 101]])
    v = np.array([5,23,102])
    s = [i, v, shape]
    d = np.array([0,0,0,0,0])
    # e = np.array([0])
    f = ['1']
    input_api.enqueue("my-t", s=d)
    # input_api.enqueue("my-table", t1=e, t2=e,t3=e,t4=e,t5=e)
    # exit(0)
    #
    time.sleep(3)
    print(output_api.query('my-t'))
    exit(0)

    # get all result and dequeue
    result = output_api.dequeue()
    for k in result.keys():
        output = "image: " + k + ", classification-result:"
        tmp_list = json.loads(result[k])
        for record in range(len(tmp_list)):
            output += " class: " + str(tmp_list[record][0]) \
                      + "'s prob: " + str(tmp_list[record][1])
        print(output)


if __name__ == "__main__":
    parser = OptionParser()
    parser.add_option("-i", "--image_path", dest="path", default="test_image")
    import sys
    (options, args) = parser.parse_args(sys.argv)
    run(options.path)
