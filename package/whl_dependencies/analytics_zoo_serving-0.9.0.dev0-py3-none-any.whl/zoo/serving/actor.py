import pykka
import redis


class RedisPutActor(pykka.ThreadingActor):
    def __init__(self):
        self.redis_cli = redis.Redis()

    def on_receive(self, message):
        pass
