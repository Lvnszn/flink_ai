from zoo.serving.client import InputQueue, OutputQueue
import time
from optparse import OptionParser


def run():
    input_api = InputQueue("localhost", "6379", True, frontend_url="http://10.239.158.161:10020")
    output_api = OutputQueue()
    output_api.dequeue()
    import numpy as np
    f = np.array([[1,2],[3,4]])
    e = np.array([1, 2])
    s = '''{
          "instances": [
            {
              "t": [1.0, 2.0]
            }
          ]
        }'''
    # input_api.enqueue('a', a=f)
    # exit(1)
    a = input_api.predict(s)
    print(a)


if __name__ == "__main__":
    run()
