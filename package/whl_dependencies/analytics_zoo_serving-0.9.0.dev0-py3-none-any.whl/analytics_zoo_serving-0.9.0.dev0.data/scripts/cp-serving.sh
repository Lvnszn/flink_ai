rm zoo.jar &&
cp ../../zoo/target/*serving* .
mv analy* zoo.jar
