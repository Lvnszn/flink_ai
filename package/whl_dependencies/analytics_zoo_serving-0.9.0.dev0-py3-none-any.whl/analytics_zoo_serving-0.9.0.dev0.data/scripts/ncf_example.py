from zoo.serving.client import InputQueue, OutputQueue
import time
from optparse import OptionParser


def run(path):
    input_api = InputQueue("localhost", "6379")
    base_path = path
    if not base_path:
        raise EOFError("You have to set your image path")
    output_api = OutputQueue()
    output_api.dequeue()
    import numpy as np
    e = np.array([1, 2])
    input_api.enqueue("my-t", s=e)
    time.sleep(3)
    print(output_api.query('my-t'))


if __name__ == "__main__":
    parser = OptionParser()
    parser.add_option("-i", "--image_path", dest="path", default="test_image")
    import sys
    (options, args) = parser.parse_args(sys.argv)
    run(options.path)
