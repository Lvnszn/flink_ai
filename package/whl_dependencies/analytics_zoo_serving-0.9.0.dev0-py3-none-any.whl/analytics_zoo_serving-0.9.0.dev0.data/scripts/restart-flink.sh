$FLINK_HOME/bin/stop-cluster.sh &&
$FLINK_HOME/bin/start-cluster.sh
